#!/usr/bin/env bash
#simply place the album in a fixed place and trigger reload of this script(using signal).

echo -e "#img path=$HOME/.cache/cover.png width=280 height=280"
