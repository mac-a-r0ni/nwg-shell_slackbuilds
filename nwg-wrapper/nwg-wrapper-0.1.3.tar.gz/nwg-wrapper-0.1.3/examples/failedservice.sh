#!/usr/bin/env bash
#!/usr/bin/env bash

title="Failed Systemd Unit:"
color="#c88fae"
cmd="$(systemctl --failed)"
textfont="Fixedsys Excelsior MonoL"
# fontsize="6pt"
source ~/.config/nwg-wrapper/termout.sh


