#!/usr/bin/env bash


#!/usr/bin/env bash

title="System:"
color="#c88fae"
textfont="Fixedsys Excelsior MonoL"
# fontsize="11pt"
cmd="$(neofetch --disable wm uptime term)"
source ~/.config/nwg-wrapper/termout.sh
