requires ansifiter:
https://gitlab.com/saalen/ansifilter
