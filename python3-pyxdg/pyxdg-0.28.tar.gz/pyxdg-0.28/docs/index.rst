PyXDG |version|
===============

PyXDG is a Python library supporting various freedesktop standards.

Contents:

.. toctree::
   :maxdepth: 2
   
   basedirectory
   desktopentry
   menu
   icontheme
   mime
   recentfiles
   exceptions

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

