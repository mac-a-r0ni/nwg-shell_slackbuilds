.. module:: xdg.IconTheme

Icon Themes
===========

`XDG Icon Theme specification <http://standards.freedesktop.org/icon-theme-spec/icon-theme-spec-latest.html>`_

.. autofunction:: getIconPath

.. autofunction:: getIconData

.. autoclass:: IconData
   :members: getDisplayName, getEmbeddedTextRectangle, getAttachPoints
