#!/usr/bin/env bash

rm -r /usr/lib/python3.9/site-packages/nwg_panel*
rm /usr/bin/nwg-panel
rm /usr/bin/nwg-panel-config
rm  /usr/share/pixmaps/nwg-panel.svg
rm  /usr/share/pixmaps/nwg-shell.svg
rm  /usr/share/applications/nwg-panel-config.desktop
