#ifndef WLR_TYPES_WLR_BOX_H
#define WLR_TYPES_WLR_BOX_H

#warning "wlr_box has been moved to wlr/util/box.h"
#include <wlr/util/box.h>

#endif
