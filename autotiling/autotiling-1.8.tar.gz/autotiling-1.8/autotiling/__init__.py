from .__about__ import __version__
from .main import main

__all__ = ["main", "__version__"]
