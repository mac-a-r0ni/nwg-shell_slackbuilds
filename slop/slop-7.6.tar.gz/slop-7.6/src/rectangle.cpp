#include "rectangle.hpp"

slop::Rectangle::Rectangle() {
}
slop::Rectangle::~Rectangle() {
}
void slop::Rectangle::setPoints( glm::vec2 p1, glm::vec2 p2 ) {
}
void slop::Rectangle::draw(glm::mat4& matrix) {
}
glm::vec4 slop::Rectangle::getRect() {
    return glm::vec4();
}
