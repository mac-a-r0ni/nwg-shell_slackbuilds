# gtklock-powerbar-module
gtklock module adding power controls to the lockscreen.
## About
Adds a reboot and poweroff button the the lockscreen.
The `gtklock-module.h` header can be used when making your own modules.

__⚠️ Module version matches the compatible gtklock version. Other versions might or might not work.__
## Dependencies
- GNU Make (build-time)
- pkg-config (build-time)
- gtk+3.0
