// gtklock
// Copyright (c) 2022 Jovan Lanik

// Utility functions

#include <glib.h>

void report_error_and_exit(gchar const *format, ...) G_GNUC_PRINTF(1, 2);

