// gtklock
// Copyright (c) 2022 Jovan Lanik

// wlr-input-inhibitor

#pragma once

void input_inhibitor_get(void);
void input_inhibitor_destroy(void);

