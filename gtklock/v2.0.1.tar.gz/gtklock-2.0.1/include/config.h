// gtklock
// Copyright (c) 2022 Jovan Lanik

// Configuration

#pragma once

#include "glib.h"

void config_load(const char *path, const char *group, GOptionEntry entries[]);

