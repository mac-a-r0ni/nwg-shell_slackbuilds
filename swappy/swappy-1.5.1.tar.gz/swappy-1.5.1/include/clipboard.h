#pragma once

#include "swappy.h"

bool clipboard_copy_drawing_area_to_selection(struct swappy_state *state);
