#pragma once

#include "swappy.h"

void render_state(struct swappy_state *state);
