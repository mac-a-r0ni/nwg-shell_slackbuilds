#pragma once

bool folder_exists(const char *path);
bool file_exists(const char *path);
char *file_dump_stdin_into_a_temp_file();
