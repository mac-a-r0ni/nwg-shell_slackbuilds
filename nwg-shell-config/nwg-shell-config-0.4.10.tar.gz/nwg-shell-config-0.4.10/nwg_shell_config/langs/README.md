# Translation

1. Copy the `en_US.json` file as `xx_YY.json`, where `xx_YY` represents your locale `$LANG` value
(the part before the dot, as "pl_PL" in "pl_PL.UTF-8".
2. Translate values in `"key": "value"` pairs into your language.

## Notes:

### The 0.4.3 version comes with 2 new, previously forgotten phrases:

```json
{
  "apply-tooltip": "Apply changes, export includes, reload sway.",
  "close-tooltip": "Close the window w/o applying changes."
}
```
